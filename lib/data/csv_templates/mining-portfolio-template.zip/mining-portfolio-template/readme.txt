To upload your mining portfolio as a CSV you will need the exact names of the companies in your portfolio, as well as the ISO3 codes of the countries in your portfolio.

See the file 'countries.csv' for a list of country ISO3 codes.  The file is UTF-8 encoded.

---

In the CSV template 'template.csv', each line represents a company in your portfolio.

You must include at least 2 companies in the CSV.

There are 2 columns: 'company_name' and 'country_isos'.

***COMPANY NAME***

The name of the company is entered in the first column with the header 'company_name' and must exactly match the name in the ENCORE database. 

If you would like to check what this name is, try searching for your company in the manual portfolio creation form: (https://https://encore.naturalcapitalfinancealliance.org/en/tools/biodiversity-goals)

***COUNTRY ISOS***

In the 'country_isos' column, please enter a comma separated list of all the ISO3 codes for all the countries you would like to include for the given company. 

A blank entry for this column represents 'global' and is the equivalent to including all countries.

Note, this list must be wrapped in double quotes, as in the template example. If you are exporting a csv from software such as Excel or Numbers, make sure that it includes these double quotes.

***NOTES***

Do not include the same company on multiple lines.

Do not edit or remove any of the column headers (e.g. 'company_name')