To upload your agriculture portfolio as a CSV you will need the list of countries in your portfolio, as well as the area (in hectares) or turnover (in million USD) for these countries.

See the file 'countries.csv' for a list of country ISO3 codes. The list includes all the countries for which ENCORE has sufficient data to include in the Agriculture Dashboard. The file is UTF-8 encoded.

---

In the CSV template 'template.csv', each line represents a country in your portfolio.

You must include at least one country-area or country-turnover combination in the CSV.

There are five columns: 'country_iso', 'crops_value', 'crops_area_type', 'livestock_value' and 'livestock_area_type'

***COUNTRY ISO***

In the 'country_isos' column, please enter the ISO3 code of the country. Do not leave this blank.

***Cropland and Pastureland Data***

Considering one line in the CSV:

If you wish to enter data for pasture land (livestock), indicate whether you are entering area of pasture land (in hectares) or turnover (in million USD) by entering 'area' or 'turnover' in the 'livestock_area_type' column. Do not enter anything else in this column and do not leave this column blank if you wish to enter a value for pasture land.

Then add the value (area or turnover as indicated) to the livestock_value column.

If you wish to enter data for cropland, the process is the same, but you need to enter the area type in the 'crops_area_type' column and the value in the 'crops_value' column.

You must include cropland and/or pasture land for all countries (lines) in the csv.

***NOTES***

Do not include the same country on multiple lines.

Do not edit or remove any of the column headers (e.g. 'country_iso', 'crops_value).

The ONLY accepted area types are: 'turnover', 'area'.

Do not forget to enter data in the correct units.
